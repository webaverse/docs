# WebXR Perlin Noise Blob

This is a ThreeJS demo that has been added to a WebXR scene.

![Blob GIF](Blob.gif)

[Original Codepen Demo by Faris K](https://codepen.io/farisk/pen/vrbzwL)

[NoiseJS](https://github.com/josephg/noisejs)

[WebXR Template](https://github.com/Zetaphor/webxr-template)

[Glitch Demo](https://glitch.com/edit/#!/webxr-blob)